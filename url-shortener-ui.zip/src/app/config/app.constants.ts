/**
 * Capture all app constants
 */
export const appConstants = {
  maxLength: {
    ESSAY: 250,
  },
  APPEARANCE: 'legacy',
};
